# Rinon-Lootbug-mod
change the Lethal Company Hoarding Bug chitterSFX to Rinons famous "Hellooooo"

## Manual Install Instructions
1. Install BepInEx
2. Extract Rinhello.dll and rinonhello into the Plugins folder of BepInEx

## Credit
- MrMiinxx / GameMasterDevs videos on basic mod creation https://www.youtube.com/watch?v=4Q7Zp5K2ywI
- RinonBanana for the funny Hellooo https://www.twitch.tv/rinbanana
